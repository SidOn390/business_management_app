// File: lib/app_router.dart

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'screens/auth/auth_gate.dart';
import 'screens/dashboard/dashboard_screen.dart';
import 'screens/receipt_entry/receipt_entry_screen.dart';
import 'screens/receipt_entry/receipt_list_screen.dart';
import 'screens/delivery_entry/delivery_entry_screen.dart';
import 'screens/delivery_entry/delivery_history_screen.dart';
import 'screens/billing_checker/billing_checker_screen.dart';
import 'screens/reports/reports_screen.dart';
import 'screens/masters/masters_menu_screen.dart';
import 'screens/masters/cold_storage_master_screen.dart';
import 'screens/masters/product_master_screen.dart';
import 'screens/masters/brand_master_screen.dart';

class AppRouter {
  static const authGate = '/';
  static const dashboard = '/dashboard';
  static const receiptEntry = '/receipt-entry';
  static const receiptList = '/receipt-list';
  static const deliveryEntry = '/delivery-entry';
  static const deliveryHistory = '/delivery-history';
  static const billingChecker = '/billing-checker';
  static const reports = '/reports';
  static const mastersMenu = '/masters';
  static const coldStorageMaster = '/masters/cold-storages';
  static const productTypeMaster = '/masters/product-types';
  static const brandMaster = '/masters/brands';

  static Route<dynamic> generateRoute(RouteSettings settings) {
    final isAuth = FirebaseAuth.instance.currentUser != null;

    Widget screenBuilder(Widget w) => isAuth ? w : const AuthGate();

    switch (settings.name) {
      case authGate:
        return MaterialPageRoute(builder: (_) => const AuthGate());
      case dashboard:
        return MaterialPageRoute(
          builder: (_) => screenBuilder(const DashboardScreen()),
        );
      case receiptEntry:
        return MaterialPageRoute(
          builder: (_) => screenBuilder(const ReceiptEntryScreen()),
        );
      case receiptList:
        return MaterialPageRoute(
          builder: (_) => screenBuilder(const ReceiptListScreen()),
        );
      case deliveryEntry:
        return MaterialPageRoute(
          builder: (_) => screenBuilder(const DeliveryEntryScreen()),
        );
      case deliveryHistory:
        return MaterialPageRoute(
          builder: (_) => screenBuilder(const DeliveryHistoryScreen()),
        );
      case billingChecker:
        return MaterialPageRoute(
          builder: (_) => screenBuilder(const BillingCheckerScreen()),
        );
      case reports:
        return MaterialPageRoute(
          builder: (_) => screenBuilder(const ReportsScreen()),
        );
      case mastersMenu:
        return MaterialPageRoute(
          builder: (_) => screenBuilder(const MastersMenuScreen()),
        );
      case coldStorageMaster:
        return MaterialPageRoute(
          builder: (_) => screenBuilder(const ColdStorageMasterScreen()),
        );
      case productTypeMaster:
        return MaterialPageRoute(
          builder: (_) => screenBuilder(const ProductMasterScreen()),
        );
      case brandMaster:
        return MaterialPageRoute(
          builder: (_) => screenBuilder(const BrandMasterScreen()),
        );
      default:
        return MaterialPageRoute(builder: (_) => const AuthGate());
    }
  }
}
